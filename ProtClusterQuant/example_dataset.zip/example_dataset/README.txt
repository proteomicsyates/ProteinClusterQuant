

In order to run ProteinClusterQuant, you will have to modify the CFBE_setup.properties file.
Change the folder locations to point to the paths in your system.

Run ProteinClusterQuant as:

> java -jar ProteinClusterQuant.jar CFBE_setup.properties


Contact to salvador at scripps.edu